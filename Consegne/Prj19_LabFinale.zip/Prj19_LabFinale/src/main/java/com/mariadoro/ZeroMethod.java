package com.mariadoro;


//marker = interfaccia senza metodi
public interface ZeroMethod {
    String saluto = "Ciao!";

}
