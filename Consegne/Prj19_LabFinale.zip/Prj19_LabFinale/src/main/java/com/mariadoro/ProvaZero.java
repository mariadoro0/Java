package com.mariadoro;

public class ProvaZero implements ZeroMethod{

}
