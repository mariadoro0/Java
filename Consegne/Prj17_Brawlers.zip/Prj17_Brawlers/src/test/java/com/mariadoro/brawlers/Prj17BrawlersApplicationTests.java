package com.mariadoro.brawlers;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Prj17BrawlersApplicationTests {

	@Test
	void contextLoads() {
	}

}
