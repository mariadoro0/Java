package com.mariadoro.hellospringboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Prj13SpringBootApplication {

	public static void main(String[] args) {
		SpringApplication.run(Prj13SpringBootApplication.class, args);
	}

}
