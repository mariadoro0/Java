package com.mariadoro.hellospringboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Prj13SpringBootApplicationTests {

	@Test
	void contextLoads() {
	}

}
