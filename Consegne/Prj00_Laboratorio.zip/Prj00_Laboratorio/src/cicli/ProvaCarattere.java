package cicli;

public class ProvaCarattere {
    public static void main(String[] args) {
        for(int i=0;i<8000;i++){
            System.out.println("Valore: "+i+" Carattere corrispondente: "+(char)i);
        }
    }
}
