package classi;

public class Autore {
    private int id;
    private String nome;
    private String cognome;
}
