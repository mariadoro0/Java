package com.mariadoro.quizmondo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Prj18QuizMondoApplicationTests {

	@Test
	void contextLoads() {
	}

}
